sap.ui.define([
	"biat.fiori.app/test/unit/controller/Biat.controller"
], function () {
	"use strict";
});
