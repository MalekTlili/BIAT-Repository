sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("biat.fiori.app.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  