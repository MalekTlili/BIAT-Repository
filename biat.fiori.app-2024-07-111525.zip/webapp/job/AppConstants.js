sap.ui.define([
], function () {
    "use strict";
    return {
        "RUN_JOB_EVENT": "RUN_JOB",
        "JOB_CHANNEL": "JOB_CHANNEL",
        "Z_USER_INFO_EVENT": "Z_USER_INFO"
    };
});